# Convert css to scss

Take main.css and run it through:

* beautifytools
* css2scss
* cssportal
* herokuapp

# Convert scss to css

Use the sass watcher in vscode to compile scss to css.

# Winner

The winner seems to be herokuapp.

* Keeps your comments
* Compiles successfully
* Inserts moz where there is no moz?  Not sure which is doin it...
* Smallest footprint

