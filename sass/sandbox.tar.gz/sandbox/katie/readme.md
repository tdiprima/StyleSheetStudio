# How to Create a Dark Mode in Sass
## Katie McTigue

### [Article](https://medium.com/@katiemctigue/how-to-create-a-dark-mode-in-sass-609f131a3995)

## The current prominent approach to theming in Sass

### Problem:

Sass can't just swap all your variables on the fly after it is already compiled.

### Solution:

Fortunately there are some excellent ideas on the web for how to solve this problem. They all boil down to more or less the same thing:

1. Assign a toggle-able "root" theme class to the body element (or app root, for React land) like theme--light.
2. Write a fancy Sass method that uses the built-in Sass map__get function to iterate through an array of themes (more on this later).
3. Call your fancy method when you have a color that you want to use.

```
.theme--dark {
   .my-div {
       background: #333;
   }
}
.theme--light {
   .my-div {
       background: #ebebeb;
   }
}
```