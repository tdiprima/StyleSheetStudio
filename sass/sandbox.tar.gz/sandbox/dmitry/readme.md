# Theming Web Apps with SASS
## Dmitry Borody

https://medium.com/@dmitriy.borodiy/easy-color-theming-with-scss-bc38fd5734d1

https://codepen.io/dmitriy_borodiy/pen/RKzwJp

So the `@themify` mixin iterates over all themes (line 2) and outputs whatever was wrapped inside it with a `.theme-#{themeName}` class selector added before (lines 4–13, and compare SCSS and compiled CSS code above).

Before outputting the wrapped content (line 11), it defines a global SASS map named `$theme-map` which contains values defined for the current theme (lines 5–9), so that the wrapped content can access them. After outputting the wrapped content (line 11), the map is set to null (line 12) so that it can't be accessed from anywhere but the mixin content.

A helper function `themed()` is meant to be used inside the wrapped content and simplifies access to the $theme-map. Voilà, no magic!

